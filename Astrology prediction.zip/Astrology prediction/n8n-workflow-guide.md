# n8n Workflow Setup Guide

This guide will help you set up the n8n workflow to process astrology prediction requests and send personalized emails.

## Prerequisites

1. **n8n Installation**: You need n8n installed and running. Options:
   - Self-hosted: Install via npm (`npm install n8n -g`) or Docker
   - Cloud: Use n8n.cloud (free tier available)
   - Desktop App: Download from n8n.io

2. **Email Service**: Configure an email service (SMTP) for sending predictions:
   - Gmail SMTP
   - SendGrid
   - Mailgun
   - AWS SES
   - Or any SMTP-compatible service

3. **LLM API Access**: You'll need access to an LLM API:
   - OpenAI GPT-4/GPT-3.5
   - Anthropic Claude
   - Google Gemini
   - Or any compatible LLM API

## Workflow Structure

The workflow consists of 4 main nodes:

1. **Webhook** - Receives form submissions
2. **Set** - Formats data for LLM processing
3. **OpenAI/Custom LLM** - Generates astrology predictions
4. **Email** - Sends predictions to users

## Step-by-Step Setup

### Step 1: Create Webhook Node

1. In n8n, create a new workflow
2. Add a **Webhook** node
3. Configure:
   - **HTTP Method**: POST
   - **Path**: `/astrology-prediction` (or your preferred path)
   - **Response Mode**: "Respond to Webhook"
   - **Response Code**: 200
   - **Response Data**: `{{ { "success": true, "message": "Request received" } }}`

4. **Save** the workflow and copy the webhook URL
5. Update `WEBHOOK_URL` in `script.js` with this URL

### Step 2: Add Set Node (Data Formatting)

1. Add a **Set** node after the Webhook
2. Configure to extract and format data:

```json
{
  "fullName": "={{ $json.body.fullName }}",
  "dateOfBirth": "={{ $json.body.dateOfBirth }}",
  "timeOfBirth": "={{ $json.body.timeOfBirth || 'Not provided' }}",
  "placeOfBirth": "={{ $json.body.placeOfBirth }}",
  "gender": "={{ $json.body.gender || 'Not specified' }}",
  "areaOfFocus": "={{ $json.body.areaOfFocus }}",
  "email": "={{ $json.body.email }}"
}
```

### Step 3: Add LLM Node (Astrology Prediction)

1. Add an **OpenAI** node (or your preferred LLM node)
2. Configure:
   - **Operation**: "Chat"
   - **Model**: GPT-4 or GPT-3.5-turbo
   - **Messages**: Use the following prompt structure

#### Responsible AI Prompt Template

```
You are a thoughtful and ethical astrologer providing guidance based on birth chart information.

User Information:
- Name: {{ $json.fullName }}
- Date of Birth: {{ $json.dateOfBirth }}
- Time of Birth: {{ $json.timeOfBirth }}
- Place of Birth: {{ $json.placeOfBirth }}
- Gender: {{ $json.gender }}
- Area of Focus: {{ $json.areaOfFocus }}

Instructions:
1. Generate a personalized astrology prediction focusing on the requested area ({{ $json.areaOfFocus }})
2. Structure your response clearly with sections
3. Use supportive, encouraging language
4. Avoid absolute claims or guarantees
5. Include guidance rather than definitive predictions
6. Keep the response between 400-600 words
7. Use appropriate astrological terminology but explain complex concepts

Important Guidelines:
- DO NOT make medical diagnoses or health claims
- DO NOT make absolute predictions about life events
- DO NOT provide financial advice or investment recommendations
- DO use conditional language (e.g., "may," "could," "might," "tend to")
- DO emphasize personal agency and free will
- DO provide general guidance and insights
- DO acknowledge that astrology is one tool among many for self-reflection

Format your response as follows:

# Personalized Astrology Prediction for {{ $json.fullName }}

## Birth Chart Overview
[Brief overview based on birth information]

## {{ $json.areaOfFocus }} Insights
[Main content focusing on the requested area]

## Guidance & Recommendations
[Actionable, supportive guidance]

## Important Disclaimer
This prediction is provided for guidance and entertainment purposes only. Astrology is not a substitute for professional advice in medical, legal, financial, or other matters. Your choices and actions shape your future.
```

3. Set **Temperature**: 0.7 (for balanced creativity)
4. Set **Max Tokens**: 800

### Step 4: Add Email Node

1. Add an **Email Send** node (or SMTP node)
2. Configure your email service:
   - **From Email**: Your service email (e.g., predictions@yourdomain.com)
   - **To Email**: `={{ $json.email }}`
   - **Subject**: `Your Personalized Astrology Prediction - {{ $json.fullName }}`
   - **Email Type**: HTML
   - **Message**: 

```html
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }
        .disclaimer { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin-top: 20px; border-radius: 5px; }
        h1 { margin: 0; }
        h2 { color: #667eea; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✨ Your Astrology Prediction</h1>
        </div>
        <div class="content">
            <p>Dear {{ $json.fullName }},</p>
            <p>Thank you for requesting your personalized astrology prediction. Based on your birth information, here are your insights:</p>
            
            {{ $json.prediction }}
            
            <div class="disclaimer">
                <p><strong>Disclaimer:</strong> This astrology prediction is provided for guidance and entertainment purposes only. It should not be used as a substitute for professional advice in medical, legal, financial, or other matters. Astrology is one tool among many for self-reflection and personal growth.</p>
            </div>
            
            <p>Best wishes,<br>The Astrology Prediction Team</p>
        </div>
    </div>
</body>
</html>
```

### Step 5: Error Handling (Optional but Recommended)

1. Add an **IF** node after the LLM node to check for errors
2. Add an **Email Send** node for error notifications
3. Configure to send error alerts to your admin email

### Step 6: Test the Workflow

1. Use the webhook URL in a test tool (Postman, curl, or your frontend)
2. Send a test payload:
```json
{
  "fullName": "Test User",
  "dateOfBirth": "1990-01-15",
  "timeOfBirth": "10:30",
  "placeOfBirth": "New York, USA",
  "gender": "other",
  "areaOfFocus": "career",
  "email": "test@example.com"
}
```

3. Verify the email is received with proper formatting

## Workflow JSON Export

For convenience, you can import this workflow structure. The exact JSON will depend on your n8n version and configuration.

## Security Considerations

1. **Webhook Security**: Consider adding authentication:
   - API key validation in the webhook
   - Rate limiting
   - IP whitelisting

2. **Email Validation**: Validate email addresses before sending

3. **Data Privacy**: 
   - Don't log sensitive personal information
   - Consider data retention policies
   - Comply with GDPR/privacy regulations

4. **Error Handling**: Don't expose internal errors to users

## Monitoring and Maintenance

1. Set up workflow monitoring in n8n
2. Monitor email delivery rates
3. Track LLM API usage and costs
4. Review prediction quality periodically
5. Update prompts based on feedback

## Troubleshooting

**Webhook not receiving data:**
- Check webhook URL is correct
- Verify CORS settings if needed
- Check n8n logs

**LLM not generating predictions:**
- Verify API credentials
- Check API rate limits
- Review prompt formatting

**Emails not sending:**
- Verify SMTP credentials
- Check spam folders
- Test email service independently

## Cost Estimation

- **n8n**: Free for self-hosted, or cloud pricing
- **LLM API**: ~$0.01-0.05 per prediction (depending on model)
- **Email Service**: Varies (many free tiers available)

## Next Steps

1. Test the complete workflow end-to-end
2. Update the webhook URL in `script.js`
3. Deploy your frontend to GitHub Pages
4. Monitor and iterate based on user feedback
