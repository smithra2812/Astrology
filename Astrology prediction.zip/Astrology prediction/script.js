
const form = document.getElementById('astrologyForm');
const submitBtn = document.getElementById('submitBtn');
const btnText = submitBtn.querySelector('.btn-text');
const btnLoader = submitBtn.querySelector('.btn-loader');


const WEBHOOK_URL = 'http://localhost:5678/webhook-test/Astro';


const validationRules = {
    fullName: {
        required: true,
        minLength: 2,
        pattern: /^[a-zA-Z\s'-]+$/,
        message: 'Please enter a valid name (letters, spaces, hyphens, and apostrophes only)'
    },
    dateOfBirth: {
        required: true,
        validate: (value) => {
            const date = new Date(value);
            const today = new Date();
            return date < today;
        },
        message: 'Please enter a valid date of birth'
    },
    placeOfBirth: {
        required: true,
        minLength: 3,
        message: 'Please enter a valid place of birth'
    },
    email: {
        required: true,
        pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        message: 'Please enter a valid email address'
    },
    areaOfFocus: {
        required: true,
        message: 'Please select an area of focus'
    }
};


function validateField(fieldName, value) {
    const rules = validationRules[fieldName];
    if (!rules) return true;

    const errorElement = document.getElementById(`${fieldName}Error`);
    
   
    if (rules.required && !value.trim()) {
        errorElement.textContent = 'This field is required';
        return false;
    }

  
    if (rules.minLength && value.length < rules.minLength) {
        errorElement.textContent = rules.message || `Minimum ${rules.minLength} characters required`;
        return false;
    }

    
    if (rules.pattern && !rules.pattern.test(value)) {
        errorElement.textContent = rules.message;
        return false;
    }

   
    if (rules.validate && !rules.validate(value)) {
        errorElement.textContent = rules.message;
        return false;
    }

    // Clear error if valid
    errorElement.textContent = '';
    return true;
}

// Validate entire form
function validateForm(formData) {
    let isValid = true;
    
    Object.keys(validationRules).forEach(fieldName => {
        const value = formData.get(fieldName);
        if (!validateField(fieldName, value || '')) {
            isValid = false;
        }
    });

    return isValid;
}

// Real-time validation
form.addEventListener('input', (e) => {
    const fieldName = e.target.name;
    if (validationRules[fieldName]) {
        validateField(fieldName, e.target.value);
    }
});

form.addEventListener('blur', (e) => {
    const fieldName = e.target.name;
    if (validationRules[fieldName]) {
        validateField(fieldName, e.target.value);
    }
}, true);

// Format form data for submission
function formatFormData(formData) {
    const data = {
        fullName: formData.get('fullName').trim(),
        dateOfBirth: formData.get('dateOfBirth'),
        placeOfBirth: formData.get('placeOfBirth').trim(),
        areaOfFocus: formData.get('areaOfFocus'),
        email: formData.get('email').trim().toLowerCase()
    };

    // Only include optional fields if they have a value
    const timeOfBirth = formData.get('timeOfBirth');
    if (timeOfBirth) data.timeOfBirth = timeOfBirth;

    const gender = formData.get('gender');
    if (gender) data.gender = gender;

    return data; // ✅ always valid JSON
}


// Show message to user
function showMessage(message, type = 'success') {
    const messageElement = document.getElementById('formMessage');
    messageElement.textContent = message;
    messageElement.className = `form-message ${type}`;
    messageElement.style.display = 'block';
    
    // Scroll to message
    messageElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    
    // Hide after 5 seconds for success messages
    if (type === 'success') {
        setTimeout(() => {
            messageElement.style.display = 'none';
        }, 5000);
    }
}

// Handle form submission
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Check if webhook URL is configured
    if (WEBHOOK_URL === 'YOUR_N8N_WEBHOOK_URL_HERE') {
        showMessage('Please configure the webhook URL in script.js', 'error');
        return;
    }
    
    const formData = new FormData(form);
    
    // Validate form
    if (!validateForm(formData)) {
        showMessage('Please correct the errors in the form', 'error');
        return;
    }
    
    // Format data
    const submissionData = formatFormData(formData);
    
    // Disable submit button and show loading
    submitBtn.disabled = true;
    btnText.style.display = 'none';
    btnLoader.style.display = 'inline-block';
    
    try {
const response = await fetch(WEBHOOK_URL, {
    method: 'POST',
    headers: {
        'Authorization': 'Bearer abc123xyz456', // <-- real key here
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(submissionData)
});

        
        if (!response.ok) {
            throw new Error(`Server responded with status: ${response.status}`);
        }
        
        const result = await response.json();
        
        // Success message
        showMessage(
            'Thank you! Your request has been submitted successfully. Check your email for your personalized astrology prediction.',
            'success'
        );
        
        // Reset form after successful submission
        setTimeout(() => {
            form.reset();
            // Clear all error messages
            document.querySelectorAll('.error-message').forEach(el => {
                el.textContent = '';
            });
        }, 2000);
        
    } catch (error) {
        console.error('Submission error:', error);
        showMessage(
            'Sorry, there was an error submitting your request. Please try again later or contact support.',
            'error'
        );
    } finally {
        // Re-enable submit button
        submitBtn.disabled = false;
        btnText.style.display = 'inline-block';
        btnLoader.style.display = 'none';
    }
});

// Set max date to today for date of birth
const dateOfBirthInput = document.getElementById('dateOfBirth');
const today = new Date().toISOString().split('T')[0];
dateOfBirthInput.setAttribute('max', today);
