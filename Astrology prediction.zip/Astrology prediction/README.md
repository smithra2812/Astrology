# ✨ Astrology Prediction Website

A modern, AI-powered astrology prediction website that collects user birth information and delivers personalized astrological insights via email.

## 🌟 Features

- **Beautiful, Modern UI**: Responsive design with gradient styling and smooth animations
- **Comprehensive Form**: Collects all necessary astrological data (name, DOB, time, place, gender, focus area)
- **Input Validation**: Real-time validation with helpful error messages
- **AI-Powered Predictions**: Uses LLM to generate personalized astrology insights
- **Email Delivery**: Automated email delivery of predictions
- **Responsible AI**: Thoughtful prompt design with ethical guidelines and disclaimers
- **GitHub Pages Ready**: Easy deployment to GitHub Pages

## 🚀 Quick Start

### Frontend Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/astrology-prediction.git
   cd astrology-prediction
   ```

2. **Configure Webhook URL**
   - Open `script.js`
   - Replace `YOUR_N8N_WEBHOOK_URL_HERE` with your n8n webhook URL
   ```javascript
   const WEBHOOK_URL = 'https://your-n8n-instance.com/webhook/astrology-prediction';
   ```

3. **Deploy to GitHub Pages**
   - Push code to GitHub repository
   - Go to Settings → Pages
   - Select source branch (usually `main`)
   - Your site will be available at `https://yourusername.github.io/astrology-prediction`

### n8n Workflow Setup

See [n8n-workflow-guide.md](./n8n-workflow-guide.md) for detailed instructions on setting up the automation workflow.

**Quick Overview:**
1. Install n8n (self-hosted or cloud)
2. Create workflow with Webhook → Set → LLM → Email nodes
3. Configure LLM with responsible AI prompt
4. Set up email service (SMTP)
5. Test workflow end-to-end

## 📁 Project Structure

```
astrology-prediction/
├── index.html          # Main HTML form
├── styles.css          # Styling and responsive design
├── script.js          # Form validation and webhook submission
├── n8n-workflow-guide.md  # Detailed n8n setup instructions
├── RESPONSIBLE_AI.md      # AI ethics and usage documentation
└── README.md          # This file
```

## 🎨 Frontend Features

### Form Fields

- **Full Name** (required): Text input with name validation
- **Date of Birth** (required): Date picker with max date validation
- **Time of Birth** (optional): Time input for more accurate predictions
- **Place of Birth** (required): City and country
- **Gender** (optional): Dropdown selection
- **Area of Focus** (required): Career, Health, Relationships, Finance, etc.
- **Email** (required): Email validation

### Validation

- Real-time field validation
- Clear error messages
- Visual feedback (green borders for valid, red for invalid)
- Form submission only when all required fields are valid

### User Experience

- Smooth animations and transitions
- Loading states during submission
- Success/error messages
- Mobile-responsive design
- Accessible form labels and structure

## 🤖 AI Integration

### Responsible AI Approach

This project demonstrates thoughtful AI usage:

- **Clear Prompts**: Well-structured prompts that guide the LLM appropriately
- **Ethical Guidelines**: Explicit instructions to avoid harmful content
- **Disclaimers**: Every prediction includes appropriate disclaimers
- **Conditional Language**: Predictions use "may," "could," "might" rather than absolutes
- **Appropriate Boundaries**: No medical, financial, or legal advice

See [RESPONSIBLE_AI.md](./RESPONSIBLE_AI.md) for comprehensive documentation.

### LLM Prompt Design

The prompt includes:
- User information formatting
- Clear instructions for the AI astrologer
- Safety guidelines and prohibitions
- Structured output requirements
- Mandatory disclaimer inclusion

## 📧 Email Delivery

Predictions are sent via email with:
- Professional HTML formatting
- Personalized greeting
- Structured prediction content
- Clear disclaimer section
- Responsive email design

## 🔒 Privacy and Security

- No data stored permanently (unless configured in n8n)
- Email addresses used only for delivery
- Birth information processed only for predictions
- Clear privacy considerations in documentation

## 🛠️ Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Automation**: n8n workflow automation
- **AI**: LLM API (OpenAI, Anthropic, or compatible)
- **Email**: SMTP service (Gmail, SendGrid, Mailgun, etc.)
- **Hosting**: GitHub Pages

## 📋 Requirements

### Frontend
- Modern web browser
- GitHub account (for Pages hosting)

### Backend (n8n)
- n8n installation (self-hosted or cloud)
- LLM API access (OpenAI, Anthropic, etc.)
- Email service (SMTP)

## 🧪 Testing

### Frontend Testing
1. Test form validation with invalid inputs
2. Test form submission with valid data
3. Verify webhook receives data correctly
4. Test on different screen sizes

### Workflow Testing
1. Send test payload to webhook
2. Verify LLM generates appropriate predictions
3. Check email delivery
4. Review prediction quality and safety

## 📝 Configuration

### Webhook URL
Update in `script.js`:
```javascript
const WEBHOOK_URL = 'your-webhook-url-here';
```

### n8n Configuration
- Webhook path: `/astrology-prediction`
- LLM model: GPT-4 or GPT-3.5-turbo recommended
- Email service: Configure SMTP credentials

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Enhanced validation
- Additional form fields
- Improved UI/UX
- Better error handling
- More sophisticated prompts

## 📄 License

This project is open source. Please review and comply with:
- LLM API terms of service
- Email service terms
- Any applicable regulations

## ⚠️ Disclaimer

**Important**: This website provides astrology predictions for guidance and entertainment purposes only. Predictions are AI-generated and should not be used as a substitute for professional advice in medical, legal, financial, or other matters.

## 📚 Documentation

- [n8n Workflow Guide](./n8n-workflow-guide.md) - Detailed setup instructions
- [Responsible AI Documentation](./RESPONSIBLE_AI.md) - AI ethics and usage guidelines

## 🐛 Troubleshooting

### Form not submitting
- Check webhook URL is configured correctly
- Verify webhook is accessible
- Check browser console for errors

### Emails not received
- Verify n8n workflow is active
- Check email service configuration
- Review spam folder
- Check n8n execution logs

### Predictions quality issues
- Review LLM prompt in n8n workflow
- Adjust temperature and max tokens
- Test with different inputs
- Refine prompt based on outputs

## 📞 Support

For issues or questions:
1. Check documentation files
2. Review n8n workflow configuration
3. Test individual components
4. Check error logs

## 🎯 Future Enhancements

Potential improvements:
- User dashboard to view past predictions
- Multiple prediction types
- Chart visualization
- Social sharing features
- Multi-language support

---

**Built with thoughtful AI integration and modern web technologies**

**Last Updated**: January 2026
